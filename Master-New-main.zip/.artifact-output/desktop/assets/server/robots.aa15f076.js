const t={name:"robots"},o=()=>"robots.txt",r=()=>"";export{t as config,o as getPath,r as render};
